

const increase=document.getElementById('inc');
const decrease=document.getElementById('dec');
const resetbtn=document.getElementById('reset');
const countlabel = document.getElementById('countlabel')
let count=0

increase.onclick = function()
{
    count+=1;
    countlabel.textContent=count;

}

decrease.onclick = function()
{
    count-=1;
    countlabel.textContent=count;

}

resetbtn.onclick = function()
{
    count=0;
    countlabel.textContent=count;

}

